
<?php include('partials/menu.php'); ?>
<?php include('../calender.php'); ?>
<?php include('partials/footer.php') ?>