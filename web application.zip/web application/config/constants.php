<?php
    // Start Session
    session_start();

    // Create Constants to Store Non-Repeating Values
    define('SITEURL', 'http://localhost/appweb/');
    define('LOCALHOST', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
    define('DB_NAME', 'clubevents');
    define('DB_PORT', '3306'); // Change this to your actual port number if it's different

    $conn = mysqli_connect(LOCALHOST, DB_USERNAME, DB_PASSWORD, DB_NAME, DB_PORT) or die(mysqli_error($conn)); // Database Connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Selecting Database
    $db_select = mysqli_select_db($conn, DB_NAME);
    if (!$db_select) {
        die("Database selection failed: " . mysqli_error($conn));
    }

    // Set charset for the connection
    mysqli_set_charset($conn, 'utf8mb4');

    
?>